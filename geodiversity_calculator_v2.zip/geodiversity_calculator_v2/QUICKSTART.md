# 🚀 GeoDiversity Calculator MaxPro - Quick Start Guide

## ⚡ **5-Minute Quick Start**

### **Step 1: Prepare Your Data**
```
Required:
✓ Boundary polygon (GPKG or SHP)
✓ Result folder (empty directory)

Optional (add any/all):
✓ Geology polygons + field name
✓ Pedology polygons + field name  
✓ DEM raster (GeoTIFF)
✓ Lakes/seas polygons
✓ Mineralogy points + field name
✓ Palaeontology points + field name
```

### **Step 2: Choose Grid Spacing**

| Your Country Size | Recommended Grid Spacing | Example Countries |
|-------------------|-------------------------|-------------------|
| < 100,000 km² | 1,000 - 5,000m | Belgium, Netherlands, Denmark |
| 100k - 1M km² | 5,000 - 10,000m | Ghana, UK, Nigeria |
| 1M - 5M km² | 10,000 - 20,000m | Ethiopia, South Africa, Mexico |
| > 5M km² | 20,000 - 50,000m | Russia, USA, Canada, Australia |

**Plugin will automatically suggest optimal spacing!**

### **Step 3: Run Plugin**
1. Click plugin icon in QGIS toolbar
2. Fill required fields (tooltips guide you)
3. Add optional layers as needed
4. Click OK
5. Monitor progress bar

### **Step 4: Review Results**
- Final grid: `{your_grid_name}.gpkg`
- Complete file list: `{your_grid_name}_MANIFEST.txt`
- All files in your result folder

---

## 🎯 **What You Get**

### **Final Grid Fields:**
| Field | Description | Range |
|-------|-------------|-------|
| `_geol_variety` | Geological diversity | 1-N unique types |
| `_pedo_variety` | Soil type diversity | 1-N unique types |
| `_geom_variety` | Landform diversity | 1-10 (geomorphon classes) |
| `_stra_max` | Stream order | 0-7 (Strahler divided by 2) |
| `_lakes` | Water body presence | 0 or 3 |
| `_mineral_idx` | Mineral occurrences | Count of unique types |
| `_fossil_idx` | Fossil occurrences | Count of unique types |
| **`_GEODIV`** | **Total geodiversity** | **Sum of all above** |

---

## 📊 **Real Examples**

### **Example 1: Ghana (238,533 km²)**
```
Grid Spacing: 5,000m × 5,000m
Expected Cells: ~9,500
Processing Time: ~20 minutes
Components: Geology + DEM + Lakes
```

**Result:** 
- `ghana_geodiv.gpkg` (final grid)
- 9,487 cells
- 8 output files
- `ghana_geodiv_MANIFEST.txt` (summary)

### **Example 2: Nigeria (923,768 km²)**
```
Grid Spacing: 10,000m × 10,000m
Expected Cells: ~9,200
Processing Time: ~25 minutes
Components: Geology + Pedology + DEM
```

**Result:**
- `nigeria_geodiv.gpkg` (final grid)
- 9,237 cells
- 11 output files
- 37% fewer cells than v1.0 (thanks to clipping!)

### **Example 3: Russia (17,098,242 km²)**
```
Grid Spacing: 50,000m × 50,000m
Expected Cells: ~6,800
Processing Time: ~30 minutes
Components: DEM only (geomorphon + Strahler)
```

**Result:**
- `russia_geodiv.gpkg` (final grid)
- 6,840 cells
- 50% fewer cells than v1.0 (thanks to clipping!)

---

## ⚠️ **Common Mistakes to Avoid**

### ❌ **DON'T:**
1. Use 1000m grid for Russia (17M km² → 170,000+ cells!)
2. Mix different CRS (all layers must match)
3. Use corrupted geometries (run Fix Geometries first)
4. Leave field names empty when layer is provided
5. Use spaces in output grid name (use underscores)

### ✅ **DO:**
1. Let plugin suggest grid spacing (watch for warnings)
2. Ensure all layers are in same CRS
3. Validate input geometries beforehand
4. Use descriptive grid names (e.g., `nigeria_2026`)
5. Check manifest file after completion

---

## 🐛 **Troubleshooting**

### **"Boundary layer is invalid!"**
```bash
# In QGIS Processing Toolbox:
Vector geometry → Fix geometries → Run on boundary layer
```

### **"SAGA algorithm failed"**
```bash
# Install SAGA GIS:
Windows: Use OSGeo4W installer
Linux: sudo apt-get install saga
Mac: brew install saga-gis
```

### **Processing is very slow**
```
1. Check grid spacing (may be too fine)
2. Plugin will warn if dataset is huge
3. Use recommended spacing from warning message
4. Consider larger grid for initial test
```

### **Wrong number of cells**
```
This is NORMAL in v2.0!
- Grid is now clipped to boundary
- Cell count will be LOWER than rectangular extent
- This is a FEATURE (faster processing)
```

---

## 📋 **Checklist Before Running**

```
Data Preparation:
□ All layers in same CRS
□ Boundary layer has no geometry errors
□ Field names are correct (case-sensitive!)
□ DEM covers entire boundary extent
□ Result folder exists and is empty

Plugin Settings:
□ Result folder selected
□ Boundary layer selected
□ Grid spacing chosen (or using default)
□ Output grid name entered (no spaces)
□ Optional layers and fields filled correctly

System Check:
□ SAGA GIS installed (for DEM processing)
□ GRASS GIS installed (for geomorphon)
□ Enough disk space (~10x boundary file size)
□ QGIS not running other heavy processes
```

---

## 📞 **Getting Help**

**Before asking for help, check:**
1. QGIS message log (View → Panels → Log Messages)
2. Manifest file (lists all outputs created)
3. This quick start guide
4. Full README.md

**Report issues:**
- GitHub Issues: [your-repo-url]
- Email: your.email@example.com
- Include: QGIS version, country name, grid spacing, error message

---

## 🎓 **Learn More**

- **Full Documentation:** See `README.md`
- **Change History:** See `CHANGES.md`
- **Implementation Details:** See `IMPLEMENTATION_SUMMARY.md`

---

## 💡 **Pro Tips**

1. **Test on small area first**
   - Use small region or province
   - Verify outputs before running full country

2. **Start with fewer components**
   - Run geology only first
   - Add more components after validating

3. **Use manifest file**
   - Great for research documentation
   - Lists all files with sizes
   - Shows analysis components used

4. **Watch the warnings**
   - Plugin suggests optimal grid spacing
   - Warnings are helpful, not errors!

5. **Save your settings**
   - Document grid spacing used
   - Note which components were included
   - Record processing time for future reference

---

## 🏆 **Success Criteria**

**Your analysis is successful if:**
- ✅ Progress bar reaches 100%
- ✅ Success message shows cell count
- ✅ Final grid appears in QGIS
- ✅ Manifest file exists in result folder
- ✅ `_GEODIV` field has values (not all NULL)

**Final grid attributes should show:**
- Field count: 8+ fields (id, geometry, + indices)
- Feature count: Matches logged cell count
- Geometry type: Polygon
- CRS: Matches boundary layer CRS

---

**Ready? Let's calculate some geodiversity! 🌍**

**Version:** 2.0 | **Updated:** 2026-01-03 | **Status:** Production-Ready ✅
