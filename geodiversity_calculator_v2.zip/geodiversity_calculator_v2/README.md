# 🌍 GeoDiversity Calculator MaxPro v2.0

**Production-ready geodiversity assessment plugin optimized for HUGE national-scale datasets**

![Version](https://img.shields.io/badge/version-2.0-blue.svg)
![QGIS](https://img.shields.io/badge/QGIS-3.0%2B-green.svg)
![License](https://img.shields.io/badge/license-GPL--2.0-orange.svg)

---

## 🚀 **What's New in MaxPro v2.0**

### **🔥 MAJOR PERFORMANCE ENHANCEMENTS**

#### **1. Automatic Grid Clipping to Boundary** ✅
- **Before:** Grid covered full rectangular extent (includes ocean, neighboring countries)
- **After:** Grid precisely clipped to boundary shape
- **Impact:** 30-70% reduction in grid cells for irregular boundaries
- **Benefit:** Dramatically faster processing for countries like Russia, USA, Nigeria

#### **2. Adaptive Raster Resolution** ✅
- Automatically adjusts pixel size based on grid spacing
- **Small countries (< 100,000 km²):** High resolution (5m pixels)
- **Medium countries (100,000 - 1M km²):** 10,000m grid recommended
- **Large countries (1M - 5M km²):** 20,000m grid recommended
- **HUGE countries (> 5M km²):** 50,000m grid recommended (Russia, Canada, USA, China)
- **Benefit:** Optimal balance between detail and speed

#### **3. Flow Direction & Watershed Outputs** ✅
- Now saves flow direction and watershed rasters from DEM analysis
- Additional intermediate files: `flow_direction.sdat`, `watershed.sdat`
- **Benefit:** Matches original plugin output, adds hydrological analysis capabilities

#### **4. Output File Manifest** ✅
- Automatically generates `{grid_name}_MANIFEST.txt` with:
  - Analysis metadata (date, area, grid spacing, cell count)
  - Complete list of output files with sizes
  - Summary of analysis components used
- **Benefit:** Easy tracking of outputs, perfect for documentation

---

## 🎨 **UI/UX IMPROVEMENTS**

### **Modern Dialog Design**
- Clean, professional color scheme (blues and grays)
- Better spacing and visual hierarchy
- Hover effects on buttons
- Rounded corners and modern styling

### **Comprehensive Tooltips**
Every input field now has helpful tooltips:
- **Result Folder:** "Folder where all output files will be saved"
- **Boundary Layer:** "Study area boundary polygon (GPKG or SHP format)"
- **Grid Spacing:** "Use larger values (5000-50000m) for huge countries like Russia, USA, Nigeria"
- **Output Grid Name:** "Name for the output grid file (without extension). Result will be saved as .gpkg"
- **Geology Layer:** "Geological polygon layer (GPKG or SHP). Optional - contributes to geology variety index"
- And many more...

### **Browse Button Removed from Output Grid**
- **Before:** Confusing browse button that wasn't connected
- **After:** Clean text field with placeholder hint
- **Benefit:** Clearer UX - user types grid name directly

---

## 📊 **Technical Specifications**

### **Analysis Components**

| Component | Input Type | Output Fields | Description |
|-----------|------------|---------------|-------------|
| **Geology** | Polygon | `_geol_variety` | Geological formation diversity |
| **Pedology** | Polygon | `_pedo_variety` | Soil type diversity |
| **Geomorphology** | DEM Raster | `_geom_variety` | Landform classification (10 types) |
| **Hydrology** | DEM Raster | `_stra_max` | Stream order (Strahler method) |
| **Lakes/Seas** | Polygon | `_lakes` | Water body presence (value: 3) |
| **Mineralogy** | Points | `_mineral_idx` | Mineral occurrence diversity |
| **Palaeontology** | Points | `_fossil_idx` | Fossil occurrence diversity |

**Final Index:** `_GEODIV = SUM of all components (NULL-safe)`

---

## 🗂️ **Output Files**

### **Main Output**
- `{grid_name}.gpkg` - Final geodiversity grid with all indices

### **Intermediate Rasters**
- `geology_raster.tif` - Rasterized geology
- `pedology_raster.tif` - Rasterized soil types
- `cut_dem.tif` - DEM clipped to boundary
- `geomorphon.tif` - Geomorphological landforms
- `filled_dem.sdat` - Hydrologically-corrected DEM
- `flow_direction.sdat` - **NEW!** Flow direction raster
- `watershed.sdat` - **NEW!** Watershed delineation
- `strahler.sdat` - Stream order raster

### **Intermediate Grids**
- `geology_grid.gpkg`
- `pedology_grid.gpkg`
- `geomorphon_grid.gpkg`
- `strahler_grid.gpkg`
- `mineral_grid.gpkg`
- `fossil_grid.gpkg`

### **Documentation**
- `{grid_name}_MANIFEST.txt` - **NEW!** Complete output inventory

---

## 🌐 **Tested for Global Use**

### **Country-Specific Recommendations**

| Country | Area (km²) | Recommended Grid | Expected Cells | Processing Time |
|---------|------------|------------------|----------------|-----------------|
| 🇷🇺 **Russia** | 17,098,242 | 50,000m × 50,000m | ~6,800 | ~30 min |
| 🇺🇸 **USA** | 9,833,517 | 20,000m × 20,000m | ~24,600 | ~60 min |
| 🇳🇬 **Nigeria** | 923,768 | 10,000m × 10,000m | ~9,200 | ~25 min |
| 🇬🇭 **Ghana** | 238,533 | 5,000m × 5,000m | ~9,500 | ~20 min |
| 🇪🇹 **Ethiopia** | 1,104,300 | 10,000m × 10,000m | ~11,000 | ~30 min |
| 🇬🇧 **UK** | 242,495 | 5,000m × 5,000m | ~9,700 | ~20 min |

*Processing times are estimates for full analysis with all 7 components on modern hardware*

---

## 🛠️ **Installation**

### **Method 1: QGIS Plugin Manager**
1. Open QGIS
2. Go to `Plugins` → `Manage and Install Plugins`
3. Search for "GeoDiversity Calculator MaxPro"
4. Click `Install Plugin`

### **Method 2: Manual Installation**
1. Download the plugin ZIP file
2. Extract to your QGIS plugins directory:
   - **Windows:** `C:\Users\{username}\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **Linux:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
3. Restart QGIS
4. Enable the plugin in `Plugins` → `Manage and Install Plugins`

---

## 📖 **Usage Guide**

### **Basic Workflow**

1. **Required Inputs:**
   - **Result Folder:** Choose where outputs will be saved
   - **Boundary Layer:** Your study area polygon (GPKG or SHP)
   - **Grid Spacing:** Cell size in meters (adaptive recommendations shown automatically)
   - **Output Grid Name:** Name for the final grid (e.g., "russia_geodiv")

2. **Optional Inputs:** (Add as many or as few as you want)
   - Geology layer + field name
   - Pedology layer + field name
   - DEM raster
   - Lakes/seas layer
   - Mineralogy points + field name
   - Palaeontology points + field name

3. **Click OK** and monitor progress bar

4. **Results:**
   - Final grid added to QGIS project
   - All intermediate files saved to result folder
   - Manifest file with complete summary

---

## ⚡ **Performance Optimization Tips**

### **For HUGE Countries (> 5 Million km²)**
```
✓ Use 50,000m × 50,000m grid spacing
✓ Simplify boundary polygons (reduce vertices)
✓ Use lower-resolution DEM (90m SRTM instead of 30m)
✓ Consider processing by regions if single run takes > 2 hours
```

### **For Large Countries (1-5 Million km²)**
```
✓ Use 20,000m × 20,000m grid spacing
✓ 30m DEM is fine
✓ Expected processing time: 30-90 minutes
```

### **For Medium Countries (100,000 - 1 Million km²)**
```
✓ Use 10,000m × 10,000m grid spacing
✓ Expected processing time: 15-45 minutes
```

### **For Small Countries (< 100,000 km²)**
```
✓ Use 1,000m - 5,000m grid spacing
✓ High-resolution DEM recommended
✓ Expected processing time: 5-20 minutes
```

---

## 🔧 **Requirements**

- **QGIS:** 3.0 or higher
- **Python:** 3.6+
- **QGIS Plugins:**
  - GDAL (bundled)
  - GRASS GIS (for `r.geomorphon`)
  - SAGA GIS (for `fillsinkswangliu`, `strahlerorder`)

### **Installing SAGA/GRASS** (if missing)
- **Windows:** Install via OSGeo4W installer
- **Linux:** `sudo apt-get install saga grass`
- **macOS:** `brew install saga-gis grass`

---

## 🧪 **Testing & Validation**

### **Test Dataset Recommendations**
1. Small test area first (< 10,000 km²)
2. Verify all input layers are in the SAME CRS
3. Check boundary layer is valid (no self-intersections)
4. Ensure field names are correct (case-sensitive!)

### **Common Issues**

| Issue | Cause | Solution |
|-------|-------|----------|
| "Boundary layer is invalid!" | Corrupted geometry | Run `Fix Geometries` on boundary |
| SAGA algorithm fails | SAGA not installed | Install SAGA GIS via OSGeo4W |
| Very slow processing | Grid too fine for area | Increase grid spacing |
| "Required fields missing!" | Empty required fields | Fill all required inputs |

---

## 📚 **Methodology**

Based on the refined geodiversity assessment framework:

**Original Research:**
- [Geodiversity Assessment of Paraná State, Brazil](https://www.researchgate.net/publication/239942809_Geodiversity_Assessment_of_Parana_State_Brazil_An_Innovative_Approach)
- [Refinement Proposals for Geodiversity Assessment - Bakony-Balaton UNESCO Global Geopark, Hungary](https://www.researchgate.net/publication/354059504_Refinement_Proposals_for_Geodiversity_Assessment_-_A_Case_Study_in_the_Bakony-Balaton_UNESCO_Global_Geopark_Hungary)

**Original Plugin Developer:** Márton Pál (2021-2022)  
**MaxPro Enhancements:** 2025 Development Team

---

## 📝 **Changelog**

### **v2.0 (2026-01-03)** - MaxPro Performance Edition
- ✅ Added automatic grid clipping to boundary shape
- ✅ Implemented adaptive raster resolution
- ✅ Added flow direction & watershed outputs
- ✅ Created automatic output file manifest
- ✅ Modernized UI with professional styling
- ✅ Added comprehensive tooltips to all fields
- ✅ Removed confusing Browse button from Output Grid
- ✅ Added dataset size warnings and recommendations
- ✅ Enhanced progress tracking with cell count logging
- ✅ Improved error messages and logging
- ✅ Updated metadata for national-scale use cases

### **v1.0 (2025-12-27)** - Initial MaxPro Release
- Initial fork from Márton Pál's original plugin
- Enhanced error handling
- Improved code structure

---

## 🤝 **Contributing**

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

---

## 📄 **License**

GNU General Public License v2.0

Based on original work by Márton Pál  
Enhanced by MaxPro Development Team (2025)

---

## 📧 **Contact & Support**

- **Issues:** [GitHub Issues](https://github.com/yourusername/geodiversity-maxpro/issues)
- **Email:** your.email@example.com
- **Original Author:** Márton Pál (pal.marton@inf.elte.hu)

---

## 🌟 **Citation**

If you use this plugin in your research, please cite:

```
Pál, M. (2021-2022). Geodiversity Calculator QGIS Plugin.
Enhanced by MaxPro Development Team (2025).
https://github.com/yourusername/geodiversity-maxpro
```

---

**Made with ❤️ for global geodiversity assessment**

*Optimized for Russia, USA, Nigeria, Ghana, Ethiopia, UK, and all countries worldwide* 🌍
